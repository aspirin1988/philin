<div class="inventor-jobs-total-applications">
    <?php echo _n( sprintf( '<strong>%d</strong> man applied', $total_applications ), sprintf( '<strong>%d</strong> people applied', $total_applications), $total_applications, 'inventor-jobs' ); ?>
</div>