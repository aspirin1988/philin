<?php //echo wp_kses( do_shortcode( '[inventor_breadcrumb]' ), wp_kses_allowed_html( 'post' ) ); ?>

<div class="listing-detail">
    <?php Inventor_Post_Types::render_listing_detail_sections(); ?>
</div><!-- /.listing-detail -->
