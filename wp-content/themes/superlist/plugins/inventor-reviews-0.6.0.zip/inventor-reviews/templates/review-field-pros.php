<div class="form-group review-form-pros">
    <label>
        <i class="fa fa-thumbs-up"></i>
        <?php echo __( 'Pros', 'inventor-reviews' ); ?>
    </label>

    <textarea id="pros"
              name="pros"
              rows="4"></textarea>
</div><!-- /.form-group -->